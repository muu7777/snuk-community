<script lang="ts">
// 섹션 마크업은 전 페이지 공용 — 모듈 레벨 1회 fetch 캐시
let sectionsCache: string | null = null
</script>

<script setup lang="ts">
import { onMounted, ref, nextTick } from 'vue'

// 시안 섹션 마크업(공용) 중 show 목록만 노출, hide 목록의 하위 요소는 숨김
const props = defineProps<{ show: string[]; hide?: string[] }>()
const html = ref('')

onMounted(async () => {
  if (sectionsCache === null) {
    sectionsCache = await fetch(`/snuk-sections.html?v=${__SNUK_ASSET_V__}`).then((r) => r.text())
  }
  html.value = sectionsCache ?? ''
  await nextTick()
  const root = document.getElementById('snuk-sections-root')
  if (root) {
    root.querySelectorAll('section').forEach((sec) => {
      ;(sec as HTMLElement).style.display = props.show.includes(sec.id) ? '' : 'none'
    })
    for (const id of props.hide ?? []) {
      const el = document.getElementById(id)
      if (el) el.style.display = 'none'
    }
    // 단독 페이지(섹션 1개)일 때만 페이지 배너 노출 — 홈처럼 여러 섹션이 겹칠 땐 유지(숨김)
    if (props.show.length === 1) {
      root.querySelectorAll<HTMLElement>('.page-banner').forEach((el) => {
        el.style.display = ''
      })
      // 배너에 같은 제목이 크게 들어가므로 상단 텍스트 제목은 숨김 — "스트리머/스트리머" 중복 제거
      // (헤더 안의 검색창 등은 유지해야 하므로 제목 요소만 숨긴다)
      root.querySelectorAll<HTMLElement>('section').forEach((sec) => {
        if (sec.querySelector('.page-banner')) {
          const title = sec.querySelector<HTMLElement>('.section-header .section-title')
          if (title) title.style.display = 'none'
        }
      })
    }
  }
  // 실데이터 렌더러 재실행 (스크립트 로드 전이면 no-op — SnukShell 이 로드 후 실행)
  ;(window as unknown as Record<string, undefined | (() => void)>).__snukInit?.()
})
</script>

<template>
  <div id="snuk-sections-root" v-html="html"></div>
</template>
