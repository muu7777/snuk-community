import api from './client'
import type {
  ApplyAnswer, Campaign, ClientLogo, CollabGame, CommunityBoard, CommunityComment, CommunityPostDetail,
  CommunityPostPage, CommunityPostSummary, ContentVideo, FreeResource, Goods, Me, MyApplication,
  MyParticipation, MypageSummary, News, NewsComment, Notice, OrderCreateRequest, OrderResponse, OrderView,
  NotificationItem, ParticipantPublic, Review, RoleRequestMine, RouletteItem, SongRequestItem, Spotlight,
  SpotlightPlatform, StreamerCommandItem, StreamerLive, StreamerNotice, StreamerPost,
  StreamerProfile, StreamerPublic, StreamerScheduleItem, Tournament, WikiSection,
  AdSlot,
} from '@/api/types'

// ----- auth -----
export const authApi = {
  me: () => api.get<Me>('/api/auth/me').then((r) => r.data),
  // 프사 파일 업로드
  uploadProfileImage: (file: File) => {
    const fd = new FormData()
    fd.append('file', file)
    return api.post<Me>('/api/auth/me/profile-image', fd, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then((r) => r.data)
  },
  // null/빈값이면 치지직 프사로 복원
  updateProfileImage: (imageUrl: string | null) =>
    api.patch<Me>('/api/auth/me/profile-image', { imageUrl }).then((r) => r.data),
  refresh: (refreshToken: string) =>
    api.post('/api/auth/refresh', { refreshToken }).then((r) => r.data),
  logout: () => api.post('/api/auth/logout'),
}

// ----- site settings (공개 화이트리스트 키 — 라이브 채널/배너 이미지) -----
export const siteSettingsApi = {
  get: () => api.get<Record<string, string>>('/api/site-settings').then((r) => r.data),
}

// ----- campaigns (public) -----
export const campaignApi = {
  list: () => api.get<Campaign[]>('/api/campaigns').then((r) => r.data),
  detail: (id: number) => api.get<Campaign>(`/api/campaigns/${id}`).then((r) => r.data),
  apply: (id: number, answers?: ApplyAnswer[]) =>
    api.post<{ applicationId: number; status: string }>(`/api/campaigns/${id}/apply`,
      answers && answers.length ? { answers } : {}).then((r) => r.data),
  myApplication: (id: number, reveal = false) =>
    api.get<MyApplication>(`/api/campaigns/${id}/my-application`, { params: { reveal } }).then((r) => r.data),
  reviews: (id: number) => api.get<Review[]>(`/api/campaigns/${id}/reviews`).then((r) => r.data),
  writeReview: (id: number, body: { title: string; content: string }) =>
    api.post<Review>(`/api/campaigns/${id}/reviews`, body).then((r) => r.data),
  // 스트리머 본인 컨텐츠 등록/수정/삭제 (STREAMER+, 소유자 또는 ADMIN)
  create: (body: Record<string, unknown>) => api.post<Campaign>('/api/campaigns', body).then((r) => r.data),
  update: (id: number, body: Record<string, unknown>) =>
    api.put<Campaign>(`/api/campaigns/${id}`, body).then((r) => r.data),
  remove: (id: number) => api.delete(`/api/campaigns/${id}`),
}

// ----- 스트리머 이미지 업로드 (STREAMER+) -----
export const uploadApi = {
  image: (file: File) => {
    const fd = new FormData()
    fd.append('file', file)
    return api.post<{ url: string }>('/api/uploads/image', fd, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then((r) => r.data)
  },
}

// ----- mypage (로그인 필요) -----
export const mypageApi = {
  summary: () => api.get<MypageSummary>('/api/mypage/summary').then((r) => r.data),
  /** 후기 마감 7일 연장(게임당 1회) */
  extendDeadline: (applicationId: number) =>
    api.post<{ applicationId: number; reviewDeadline: string }>(
      `/api/mypage/applications/${applicationId}/extend`).then((r) => r.data),
}

// ----- 스눅 뉴스 (조회 공개, 작성 REPORTER+) -----
export const newsApi = {
  list: () => api.get<News[]>('/api/news').then((r) => r.data),
  detail: (id: number) => api.get<News>(`/api/news/${id}`).then((r) => r.data),
  write: (body: { title: string; content: string; thumbnailUrl?: string | null }) =>
    api.post<News>('/api/news', body).then((r) => r.data),
  edit: (id: number, body: { title: string; content: string; thumbnailUrl?: string | null }) =>
    api.put<News>(`/api/news/${id}`, body).then((r) => r.data),
  remove: (id: number) => api.delete(`/api/news/${id}`),
  comments: (id: number) => api.get<NewsComment[]>(`/api/news/${id}/comments`).then((r) => r.data),
  addComment: (id: number, content: string) =>
    api.post<NewsComment>(`/api/news/${id}/comments`, { content }).then((r) => r.data),
  deleteComment: (id: number, commentId: number) => api.delete(`/api/news/${id}/comments/${commentId}`),
  uploadImage: (file: File) => {
    const fd = new FormData()
    fd.append('file', file)
    return api.post<{ url: string }>('/api/news/upload-image', fd, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then((r) => r.data)
  },
}

// ----- 라이브 상태 (public) -----
export const liveApi = {
  status: () => api.get<{ live: boolean; liveTitle: string }>('/api/live/status').then((r) => r.data),
  streamers: () => api.get<StreamerLive[]>('/api/live/streamers').then((r) => r.data),
}

// ----- tournaments (public) -----
export const tournamentApi = {
  list: () => api.get<Tournament[]>('/api/tournaments').then((r) => r.data),
  detail: (id: number) => api.get<Tournament>(`/api/tournaments/${id}`).then((r) => r.data),
  apply: (id: number, answers?: ApplyAnswer[]) =>
    api.post<{ participantId: number; status: string }>(`/api/tournaments/${id}/apply`,
      answers && answers.length ? { answers } : {}).then((r) => r.data),
  myParticipation: (id: number) =>
    api.get<MyParticipation>(`/api/tournaments/${id}/my-participation`).then((r) => r.data),
  participants: (id: number) =>
    api.get<ParticipantPublic[]>(`/api/tournaments/${id}/participants`).then((r) => r.data),
  // 스트리머 본인 대회 등록/수정/삭제 (STREAMER+, 소유자 또는 ADMIN)
  create: (body: Record<string, unknown>) => api.post<Tournament>('/api/tournaments', body).then((r) => r.data),
  update: (id: number, body: Record<string, unknown>) =>
    api.put<Tournament>(`/api/tournaments/${id}`, body).then((r) => r.data),
  remove: (id: number) => api.delete(`/api/tournaments/${id}`),
  // 주최자 참가자 관리 (소유 스트리머 또는 ADMIN)
  manageParticipants: (id: number) =>
    api.get<Array<{
      participantId: number; memberId: number; nickname: string; profileImageUrl: string | null
      followerSnapshot: number; status: string; appliedAt: string; answers: ApplyAnswer[]
    }>>(`/api/tournaments/${id}/participants/manage`).then((r) => r.data),
  /** 참가 신청 내역 CSV 다운로드(소유자/ADMIN) — blob 저장 */
  exportParticipants: (id: number) =>
    api.get(`/api/tournaments/${id}/participants/export`, { responseType: 'blob' })
      .then((r) => {
        const url = URL.createObjectURL(r.data as Blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `tournament-${id}-participants.csv`
        a.click()
        URL.revokeObjectURL(url)
      }),
  approveParticipant: (id: number, pid: number) =>
    api.post(`/api/tournaments/${id}/participants/${pid}/approve`),
  rejectParticipant: (id: number, pid: number) =>
    api.post(`/api/tournaments/${id}/participants/${pid}/reject`),
}

// ----- 스트리머 (public + 프로필/팔로우/개인 게시판) -----
export const streamerApi = {
  list: () => api.get<StreamerPublic[]>('/api/streamers').then((r) => r.data),
  profile: (id: number) => api.get<StreamerProfile>(`/api/streamers/${id}`).then((r) => r.data),
  follow: (id: number) =>
    api.post<{ following: boolean; followCount: number }>(`/api/streamers/${id}/follow`).then((r) => r.data),
  unfollow: (id: number) =>
    api.delete<{ following: boolean; followCount: number }>(`/api/streamers/${id}/follow`).then((r) => r.data),
  posts: (id: number) => api.get<StreamerPost[]>(`/api/streamers/${id}/posts`).then((r) => r.data),
  writePost: (id: number, body: { title: string; content: string }) =>
    api.post<StreamerPost>(`/api/streamers/${id}/posts`, body).then((r) => r.data),
  deletePost: (postId: number) => api.delete(`/api/streamer-posts/${postId}`),
  /** 글 신고(로그인 회원, 1인 1신고) — 어드민 신고함으로 접수 */
  reportPost: (postId: number, reason?: string) =>
    api.post(`/api/streamer-posts/${postId}/report`, { reason: reason ?? '' }),
}

// ----- 스트리머 페이지 심화 + 방송도우미 도구 (V23, 조회=공개 / 관리=본인·ADMIN) -----
export const streamerPageApi = {
  // 공지
  notices: (id: number) => api.get<StreamerNotice[]>(`/api/streamers/${id}/notices`).then((r) => r.data),
  createNotice: (id: number, body: { title: string; body: string; important: boolean }) =>
    api.post(`/api/streamers/${id}/notices`, body).then((r) => r.data),
  updateNotice: (noticeId: number, body: { title: string; body: string; important: boolean }) =>
    api.put(`/api/streamer-notices/${noticeId}`, body),
  deleteNotice: (noticeId: number) => api.delete(`/api/streamer-notices/${noticeId}`),
  // 방송 일정
  schedules: (id: number) => api.get<StreamerScheduleItem[]>(`/api/streamers/${id}/schedules`).then((r) => r.data),
  createSchedule: (id: number, body: { startAt: string; title: string; game: string | null; mates: string | null }) =>
    api.post(`/api/streamers/${id}/schedules`, body).then((r) => r.data),
  updateSchedule: (scheduleId: number, body: { startAt: string; title: string; game: string | null; mates: string | null }) =>
    api.put(`/api/streamer-schedules/${scheduleId}`, body),
  deleteSchedule: (scheduleId: number) => api.delete(`/api/streamer-schedules/${scheduleId}`),
  // 위키
  wiki: (id: number) => api.get<WikiSection[]>(`/api/streamers/${id}/wiki`).then((r) => r.data),
  saveWiki: (id: number, sections: WikiSection[]) =>
    api.put<WikiSection[]>(`/api/streamers/${id}/wiki`, { sections }).then((r) => r.data),
  // 명령어
  commands: (id: number) => api.get<StreamerCommandItem[]>(`/api/streamers/${id}/commands`).then((r) => r.data),
  createCommand: (id: number, body: { name: string; response: string; enabled: boolean }) =>
    api.post(`/api/streamers/${id}/commands`, body).then((r) => r.data),
  updateCommand: (commandId: number, body: Partial<{ name: string; response: string; enabled: boolean; sortOrder: number }>) =>
    api.put(`/api/streamer-commands/${commandId}`, body),
  deleteCommand: (commandId: number) => api.delete(`/api/streamer-commands/${commandId}`),
  // 룰렛
  roulette: (id: number) => api.get<RouletteItem[]>(`/api/streamers/${id}/roulette`).then((r) => r.data),
  createRouletteItem: (id: number, body: { label: string; weight: number }) =>
    api.post(`/api/streamers/${id}/roulette`, body).then((r) => r.data),
  deleteRouletteItem: (itemId: number) => api.delete(`/api/streamer-roulette/${itemId}`),
  // 노래 신청
  songs: (id: number) => api.get<{ queued: SongRequestItem[]; recent: SongRequestItem[] }>(`/api/streamers/${id}/songs`).then((r) => r.data),
  requestSong: (id: number, title: string) =>
    api.post(`/api/streamers/${id}/songs`, { title }).then((r) => r.data),
  decideSong: (songId: number, status: 'PLAYED' | 'SKIPPED') =>
    api.patch(`/api/streamer-songs/${songId}`, { status }),
  cancelSong: (songId: number) => api.delete(`/api/streamer-songs/${songId}`),
}

// ----- 알림함 (V23, 본인) -----
export const notificationApi = {
  list: () => api.get<{ unreadCount: number; items: NotificationItem[] }>('/api/notifications').then((r) => r.data),
  unreadCount: () => api.get<{ unreadCount: number }>('/api/notifications/unread-count').then((r) => r.data),
  read: (id: number) => api.post(`/api/notifications/${id}/read`),
  readAll: () => api.post('/api/notifications/read-all'),
}

// ----- 권한 신청 (V23, VIEWER→STREAMER) -----
export const roleRequestApi = {
  apply: (message: string) =>
    api.post<{ requestId: number; status: string }>('/api/role-requests', { message }).then((r) => r.data),
  mine: () => api.get<RoleRequestMine | ''>('/api/role-requests/me').then((r) => (r.status === 204 ? null : (r.data as RoleRequestMine))),
}

// ----- 무료소스 자료실 (public, 항목 19) -----
export const resourceApi = {
  list: () => api.get<FreeResource[]>('/api/resources').then((r) => r.data),
}

// ----- 공지 (public) -----
export const adApi = {
  /** 지금 노출 중인 광고 슬롯(공개) */
  list: () => api.get<AdSlot[]>('/api/ads').then((r) => r.data),
}

export const noticeApi = {
  list: (limit = 5) => api.get<Notice[]>('/api/notices', { params: { limit } }).then((r) => r.data),
}

// ----- 스포트라이트 -----
export const spotlightApi = {
  active: () => api.get<Spotlight[]>('/api/spotlights/active').then((r) => r.data),
  create: (body: { title: string; platform: SpotlightPlatform; streamUrl: string; scheduledAt?: string | null }) =>
    api.post<Spotlight>('/api/spotlights', body).then((r) => r.data),
}

// ----- goods (public storefront) -----
export const goodsApi = {
  list: () => api.get<Goods[]>('/api/goods').then((r) => r.data),
  detail: (id: number) => api.get<Goods>(`/api/goods/${id}`).then((r) => r.data),
}

// ----- orders (로그인 필요) -----
export const orderApi = {
  create: (body: OrderCreateRequest) =>
    api.post<OrderResponse>('/api/orders', body).then((r) => r.data),
  confirm: (orderId: number) =>
    api.post<OrderView>(`/api/orders/${orderId}/confirm`).then((r) => r.data),
  mine: () => api.get<OrderView[]>('/api/orders/me').then((r) => r.data),
  detail: (orderId: number) => api.get<OrderView>(`/api/orders/${orderId}`).then((r) => r.data),
}

// ----- collab (public) -----
export const collabApi = {
  games: () => api.get<CollabGame[]>('/api/collab/games').then((r) => r.data),
  videos: () => api.get<ContentVideo[]>('/api/collab/videos').then((r) => r.data),
  clients: () => api.get<ClientLogo[]>('/api/collab/clients').then((r) => r.data),
  allReviews: () => api.get<Review[]>('/api/reviews').then((r) => r.data),
}

// ----- 커뮤니티 (조회 public / 작성·댓글·버프·신고 로그인) -----
export const communityApi = {
  boards: () => api.get<CommunityBoard[]>('/api/community/boards').then((r) => r.data),
  posts: (params: { boardId?: number | null; sort?: string; q?: string; page?: number; size?: number }) =>
    api.get<CommunityPostPage>('/api/community/posts', { params }).then((r) => r.data),
  popular: (boardId?: number | null, limit = 10) =>
    api.get<CommunityPostSummary[]>('/api/community/posts/popular', { params: { boardId, limit } })
      .then((r) => r.data),
  detail: (id: number) => api.get<CommunityPostDetail>(`/api/community/posts/${id}`).then((r) => r.data),
  nearby: (id: number) =>
    api.get<CommunityPostSummary[]>(`/api/community/posts/${id}/nearby`).then((r) => r.data),
  write: (body: { boardId: number; title: string; content: string }) =>
    api.post<CommunityPostDetail>('/api/community/posts', body).then((r) => r.data),
  edit: (id: number, body: { boardId: number; title: string; content: string }) =>
    api.put<CommunityPostDetail>(`/api/community/posts/${id}`, body).then((r) => r.data),
  remove: (id: number) => api.delete(`/api/community/posts/${id}`),
  myPosts: () => api.get<CommunityPostSummary[]>('/api/community/my-posts').then((r) => r.data),
  buff: (id: number) =>
    api.post<{ buffed: boolean; buffCount: number }>(`/api/community/posts/${id}/buff`).then((r) => r.data),
  comments: (id: number) =>
    api.get<CommunityComment[]>(`/api/community/posts/${id}/comments`).then((r) => r.data),
  addComment: (id: number, content: string) =>
    api.post<CommunityComment>(`/api/community/posts/${id}/comments`, { content }).then((r) => r.data),
  deleteComment: (id: number, commentId: number) =>
    api.delete(`/api/community/posts/${id}/comments/${commentId}`),
  report: (id: number, reason: string) =>
    api.post(`/api/community/posts/${id}/report`, { reason }),
  // 공지(사이드바 공지사항과 같은 데이터) — 뉴스는 /news/{id} 기사 페이지로 이동
  noticeDetail: (id: number) =>
    api.get<CommunityPostDetail>(`/api/community/notices/${id}`).then((r) => r.data),
  deleteNotice: (id: number) => api.delete(`/api/community/notices/${id}`),
  // 글 본문 이미지 업로드 (로그인 회원)
  uploadImage: (file: File) => {
    const fd = new FormData()
    fd.append('file', file)
    return api.post<{ url: string }>('/api/community/upload-image', fd, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then((r) => r.data)
  },
}
