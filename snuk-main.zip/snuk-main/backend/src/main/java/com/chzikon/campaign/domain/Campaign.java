package com.chzikon.campaign.domain;

import com.chzikon.global.error.BusinessException;
import com.chzikon.global.error.ErrorCode;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "campaign")
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Campaign {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 200)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(name = "game_name", length = 200)
    private String gameName;

    @Column(name = "promo_image_url", length = 512)
    private String promoImageUrl;

    @Column(name = "event_date")
    private LocalDate eventDate;

    @Column(name = "apply_start")
    private LocalDateTime applyStart;

    @Column(name = "apply_end")
    private LocalDateTime applyEnd;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private CampaignStatus status = CampaignStatus.SCHEDULED;

    @Enumerated(EnumType.STRING)
    @Column(name = "distribution_type", nullable = false, length = 20)
    private DistributionType distributionType = DistributionType.FCFS;

    @Enumerated(EnumType.STRING)
    @Column(name = "key_mode", nullable = false, length = 20)
    private KeyMode keyMode = KeyMode.QUANTITY;

    @Column(name = "total_slots", nullable = false)
    private int totalSlots;

    @Column(name = "filled_slots", nullable = false)
    private int filledSlots;

    @Column(name = "is_featured", nullable = false)
    private boolean featured;

    @Column(name = "sort_order", nullable = false)
    private int sortOrder;

    /** 등록 스트리머(NULL = 어드민 등록). 본인 수정/삭제 권한 판별용. */
    @Column(name = "owner_member_id")
    private Long ownerMemberId;

    /** 신청 질문 JSON(V22, 대회 apply_questions 패턴 미러). 없으면 질문 없이 신청. */
    @Column(name = "apply_questions", columnDefinition = "TEXT")
    private String applyQuestions;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @Builder
    private Campaign(String title, String description, String gameName, String promoImageUrl,
                     LocalDate eventDate, LocalDateTime applyStart, LocalDateTime applyEnd,
                     CampaignStatus status, DistributionType distributionType, KeyMode keyMode,
                     int totalSlots, boolean featured, int sortOrder, String applyQuestions) {
        this.title = title;
        this.description = description;
        this.gameName = gameName;
        this.promoImageUrl = promoImageUrl;
        this.eventDate = eventDate;
        this.applyStart = applyStart;
        this.applyEnd = applyEnd;
        this.status = status != null ? status : CampaignStatus.SCHEDULED;
        this.distributionType = distributionType != null ? distributionType : DistributionType.FCFS;
        this.keyMode = keyMode != null ? keyMode : KeyMode.QUANTITY;
        this.totalSlots = totalSlots;
        this.filledSlots = 0;
        this.featured = featured;
        this.sortOrder = sortOrder;
        this.applyQuestions = applyQuestions;
        LocalDateTime now = LocalDateTime.now();
        this.createdAt = now;
        this.updatedAt = now;
    }

    public void update(String title, String description, String gameName, String promoImageUrl,
                       LocalDate eventDate, LocalDateTime applyStart, LocalDateTime applyEnd,
                       CampaignStatus status, DistributionType distributionType, KeyMode keyMode,
                       Integer totalSlots, Boolean featured, Integer sortOrder, String applyQuestions) {
        if (title != null) this.title = title;
        this.description = description;
        this.gameName = gameName;
        this.promoImageUrl = promoImageUrl;
        this.eventDate = eventDate;
        this.applyStart = applyStart;
        this.applyEnd = applyEnd;
        if (status != null) this.status = status;
        if (distributionType != null) this.distributionType = distributionType;
        if (keyMode != null) this.keyMode = keyMode;
        if (totalSlots != null) this.totalSlots = totalSlots;
        if (featured != null) this.featured = featured;
        if (sortOrder != null) this.sortOrder = sortOrder;
        this.applyQuestions = applyQuestions;
        this.updatedAt = LocalDateTime.now();
    }

    /** 키 등록 시 모집 정원을 키 수량에 맞춰 자동 반영(이미 확정된 인원 밑으로는 안 내려감). 어드민 수동 수정 가능. */
    public void syncTotalSlotsToKeys(int keyCount) {
        this.totalSlots = Math.max(keyCount, this.filledSlots);
        this.updatedAt = LocalDateTime.now();
    }

    /** 키 등록 시 자동으로 고유 키 배포 모드로 전환(승인 시 키 자동 배정이 동작하도록). */
    public void enableUniqueKeyMode() {
        if (this.keyMode != KeyMode.UNIQUE_KEY) {
            this.keyMode = KeyMode.UNIQUE_KEY;
            this.updatedAt = LocalDateTime.now();
        }
    }

    /** 스트리머 본인 등록 컨텐츠 표시. */
    public void assignOwner(Long memberId) {
        this.ownerMemberId = memberId;
    }

    public boolean isOwnedBy(Long memberId) {
        return this.ownerMemberId != null && this.ownerMemberId.equals(memberId);
    }

    public boolean isOpenForApply() {
        return this.status == CampaignStatus.OPEN;
    }

    /** 준비중 — 내용만 공개, 모집 정보·신청 불가. */
    public boolean isPreparing() {
        return this.status == CampaignStatus.PREPARING;
    }

    /** 스트리머 등록분은 관리자 승인 전까지 준비중으로 강제. */
    public void forcePreparing() {
        this.status = CampaignStatus.PREPARING;
        this.updatedAt = LocalDateTime.now();
    }

    /** 관리자 승인 → 모집중 전환. */
    public void approveRecruit() {
        this.status = CampaignStatus.OPEN;
        this.updatedAt = LocalDateTime.now();
    }

    /** 스트리머(비관리자)가 스스로 열 수 없는 상태 — 승인 전용. */
    public static boolean isAdminOnlyStatus(CampaignStatus s) {
        return s == CampaignStatus.OPEN || s == CampaignStatus.SCHEDULED;
    }

    public boolean hasFreeSlot() {
        return this.filledSlots < this.totalSlots;
    }

    /** 슬롯 1개 차감(원자 처리는 비관적 락 트랜잭션 내에서 호출). 소진 시 예외. */
    public void fillOneSlot() {
        if (!hasFreeSlot()) {
            throw new BusinessException(ErrorCode.CAMPAIGN_FULL);
        }
        this.filledSlots += 1;
        this.updatedAt = LocalDateTime.now();
    }
}
