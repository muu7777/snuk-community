package com.chzikon.global.error;

import org.springframework.http.HttpStatus;

/**
 * 도메인 공통 에러코드. @RestControllerAdvice 에서 일관 응답으로 매핑.
 */
public enum ErrorCode {

    // 공통
    INVALID_INPUT(HttpStatus.BAD_REQUEST, "C001", "입력값이 올바르지 않습니다."),
    NOT_FOUND(HttpStatus.NOT_FOUND, "C002", "대상을 찾을 수 없습니다."),
    UNAUTHORIZED(HttpStatus.UNAUTHORIZED, "C003", "로그인이 필요합니다."),
    FORBIDDEN(HttpStatus.FORBIDDEN, "C004", "권한이 없습니다."),
    CONFLICT(HttpStatus.CONFLICT, "C005", "요청이 현재 상태와 충돌합니다."),
    METHOD_NOT_ALLOWED(HttpStatus.METHOD_NOT_ALLOWED, "C006", "지원하지 않는 요청 방식입니다."),
    INTERNAL_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "C500", "서버 오류가 발생했습니다."),

    // 인증/권한 (AUTH)
    OAUTH_FAILED(HttpStatus.UNAUTHORIZED, "A001", "치지직 인증에 실패했습니다."),
    INVALID_TOKEN(HttpStatus.UNAUTHORIZED, "A002", "유효하지 않은 토큰입니다."),
    INSUFFICIENT_ROLE(HttpStatus.FORBIDDEN, "A003", "스트리머 이상 권한이 필요합니다."),

    // 캠페인 (CMP)
    CAMPAIGN_NOT_OPEN(HttpStatus.CONFLICT, "M001", "신청 가능한 상태가 아닙니다."),
    CAMPAIGN_FULL(HttpStatus.CONFLICT, "M002", "모집 슬롯이 모두 소진되었습니다."),
    ALREADY_APPLIED(HttpStatus.CONFLICT, "M003", "이미 신청한 캠페인입니다."),
    FOLLOWER_THRESHOLD_NOT_MET(HttpStatus.FORBIDDEN, "M004", "팔로워 임계값을 충족하지 않습니다."),
    NO_AVAILABLE_KEY(HttpStatus.CONFLICT, "M005", "배정 가능한 키가 없습니다."),
    KEY_ALREADY_ASSIGNED(HttpStatus.CONFLICT, "M006", "이미 배정된 키입니다."),
    CAMPAIGN_PREPARING(HttpStatus.CONFLICT, "M007", "준비 중인 컨텐츠입니다. 모집이 시작되면 신청할 수 있어요."),
    CAMPAIGN_HAS_ASSIGNMENTS(HttpStatus.CONFLICT, "M009", "이미 키가 배정된(승인된) 신청자가 있는 컨텐츠는 삭제할 수 없습니다. 상태를 '종료'로 바꿔 주세요."),
    CONTENT_NEEDS_APPROVAL(HttpStatus.FORBIDDEN, "M008", "스트리머 등록 컨텐츠는 관리자 승인 후 모집이 열립니다. 준비중으로 등록되고, 승인되면 모집중으로 바뀌어요."),

    // 후기 (REV)
    REVIEW_NOT_PARTICIPANT(HttpStatus.FORBIDDEN, "R001", "참가자만 후기를 작성할 수 있습니다."),
    DEADLINE_ALREADY_EXTENDED(HttpStatus.CONFLICT, "R002", "후기 마감 연장은 게임당 1회만 가능합니다."),
    DEADLINE_NOT_APPLICABLE(HttpStatus.CONFLICT, "R003", "후기 마감이 없는 신청입니다."),

    // 굿즈/결제 (GOODS)
    GOODS_NOT_AVAILABLE(HttpStatus.CONFLICT, "G001", "판매 중인 상품이 아닙니다."),
    OUT_OF_STOCK(HttpStatus.CONFLICT, "G002", "재고가 부족합니다."),
    ORDER_NOT_OWNED(HttpStatus.FORBIDDEN, "G003", "본인의 주문이 아닙니다."),
    PAYMENT_AMOUNT_MISMATCH(HttpStatus.CONFLICT, "G004", "결제 금액이 주문 금액과 일치하지 않습니다."),
    PAYMENT_NOT_PAID(HttpStatus.CONFLICT, "G005", "아직 결제가 완료되지 않았습니다."),
    PAYMENT_VERIFY_FAILED(HttpStatus.BAD_GATEWAY, "G006", "결제 검증에 실패했습니다."),
    GOODS_HAS_ORDERS(HttpStatus.CONFLICT, "G007", "주문 이력이 있는 상품은 삭제할 수 없습니다. 대신 숨김 처리하세요."),

    // 대회 (TOUR)
    TOURNAMENT_NOT_OPEN(HttpStatus.CONFLICT, "T001", "참가 신청 가능한 상태가 아닙니다."),
    TOURNAMENT_FULL(HttpStatus.CONFLICT, "T002", "참가 정원이 모두 찼습니다."),
    ALREADY_JOINED(HttpStatus.CONFLICT, "T003", "이미 참가 신청한 대회입니다."),
    TOURNAMENT_PREPARING(HttpStatus.CONFLICT, "T004", "준비 중인 대회입니다. 모집이 시작되면 참가 신청할 수 있어요."),

    // 설정 (ADM)
    SETTING_NOT_FOUND(HttpStatus.NOT_FOUND, "S001", "설정값을 찾을 수 없습니다."),

    // 스포트라이트 (SL)
    SPOTLIGHT_ACTIVE_EXISTS(HttpStatus.CONFLICT, "SL001", "이미 노출 중인 스포트라이트가 있습니다. 만료 후 다시 등록해주세요."),

    // 포인트 (PT)
    POINT_INSUFFICIENT(HttpStatus.CONFLICT, "P001", "포인트가 부족합니다."),

    // 신고 (RP)
    ALREADY_REPORTED(HttpStatus.CONFLICT, "RP001", "이미 신고한 글입니다."),

    // 커뮤니티 (CM)
    BOARD_NOT_AVAILABLE(HttpStatus.CONFLICT, "CM001", "글을 쓸 수 없는 게시판입니다."),
    BOARD_HAS_POSTS(HttpStatus.CONFLICT, "CM002", "글이 있는 게시판은 삭제할 수 없습니다. 숨김 처리해주세요."),
    BOARD_HAS_CHILDREN(HttpStatus.CONFLICT, "CM003", "하위 게시판이 있는 그룹은 삭제할 수 없습니다.");

    private final HttpStatus status;
    private final String code;
    private final String message;

    ErrorCode(HttpStatus status, String code, String message) {
        this.status = status;
        this.code = code;
        this.message = message;
    }

    public HttpStatus getStatus() {
        return status;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
